# Satis Host demo composer package

Demo composer package used with [Satis Host], for testing [Satis] hosting on [Github].

[Satis Host]: https://github.com/markchalloner/satishost
[Satis]: https://getcomposer.org/doc/articles/handling-private-packages-with-satis.md#satis
[Github]: https://github.com